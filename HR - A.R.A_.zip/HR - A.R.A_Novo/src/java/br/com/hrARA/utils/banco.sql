/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 * Author:  rodol
 * Created: 16/03/2021
 */

CREATE TABLE perfil (		  
    id_perfil serial PRIMARY KEY, 		  
    descricao_perfil varchar(100) NOT NULL,		  
    criado_perfil timestamp NOT NULL,	  
    modificado_perfil timestamp,
    cod_perfil integer NOT NULL
);
CREATE TABLE usuario(
	id_usuario serial primary key,
	nome_usuario varchar(40) NOT NULL,
    contato_usuario varchar(20) NOT NULL,		  
    email_usuario varchar(100) NOT NULL,	
    senha_usuario varchar(100) NOT NULL,
	criado_usuario timestamp NOT NULL,	
	cod_perfill integer NOT NULL, 
	id_perfil integer,
    modificado_usuario timestamp,
	CONSTRAINT fk_usuario_perfil FOREIGN KEY (id_perfil) REFERENCES perfil(id_perfil)
);
CREATE TABLE recurso(
	id_recurso serial primary key,
	nome_recurso varchar(40) NOT NULL,
    quantidade_recurso integer NOT NULL,
    status_recurso integer NOT NULL,
	criado_recurso timestamp NOT NULL,		  
    modificado_recurso timestamp
);

CREATE TABLE reserva(
	id_reserva serial primary key,
	data_reserva date NOT NULL,
    hora_reserva time NOT NULL,
	id_usuario integer NOT NULL,
	CONSTRAINT fk_reserva_usuario FOREIGN KEY (id_usuario) REFERENCES usuario(id_usuario)
);

insert into perfil (descricao_perfil, status_perfil, criado_perfil,modificado_perfil) 
values ('sadsadasasdas', 2, now(), now());
SET TIMEZONE TO 'Brazil/DeNoronha';
