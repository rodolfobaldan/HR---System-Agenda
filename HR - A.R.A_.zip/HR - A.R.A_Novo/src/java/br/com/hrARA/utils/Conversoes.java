/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.utils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

/**
 *
 * @author higor
 */
public class Conversoes {
    public static Date converterStringDate(String data) throws Exception{
        if(data != null || !data.equals("")){
            Locale locale = new Locale("pt", "BR");
            SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd",locale);
            Date novaData = fmt.parse(data);
            return novaData;
        }else
            return null;
    }
    
    public static Date converterStringTime(String data) throws Exception{
        if(data != null || !data.equals("")){
            Locale locale = new Locale("pt", "BR");
            SimpleDateFormat sdf = new SimpleDateFormat("HH:mm", locale);
            Date novaData = sdf.parse(data);
            return novaData;
        }else
            return null;
    }
}
