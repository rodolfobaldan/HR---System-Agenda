/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.controller.reserva;

import br.com.hrARA.dao.ReservaDAO;
import br.com.hrARA.model.Result;
import br.com.hrARA.model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author higor
 */
@WebServlet(name = "AprovarReserva", urlPatterns = {"/AprovarReserva"})
public class AprovarReserva extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        Result oResult = new Result();
        oResult.setId_item_reserva(Integer.parseInt(request.getParameter("id_Item_reserva")));
        
        try {
            ReservaDAO dao = new ReservaDAO();
            HttpSession session = request.getSession(true);
            String mensagem = null;
            
            if (dao.AprovarItem(oResult)) {
                    mensagem = "<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">\n" +
                                "  <strong>Agendamento aprovado!</strong>\n" +
                                "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n" +
                                "    <span aria-hidden=\"true\">&times;</span>\n" +
                                "  </button>\n" +
                                "</div>";
                } else {
                    mensagem = "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\n" +
                               "  <strong>Problemas ao aprovador!</strong>\n" +
                               "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n" +
                               "    <span aria-hidden=\"true\">&times;</span>\n" +
                               "  </button>\n" +
                               "</div>";
                }
            
            oResult = dao.LogarListarPendentesAdm();
            session.setAttribute("pendentes", oResult.getResultado());
            request.setAttribute("mensagem", mensagem);
            request.getRequestDispatcher("/DadosItemReserva").forward(request, response);
        } catch (Exception ex) {
            System.out.println("Problemas ao AprovarItem Reserva! Erro: " + ex.getMessage());
            ex.printStackTrace();
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
