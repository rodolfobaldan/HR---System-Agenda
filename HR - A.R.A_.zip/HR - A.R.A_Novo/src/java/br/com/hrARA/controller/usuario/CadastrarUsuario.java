/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.controller.usuario;

import br.com.hrARA.dao.GenericDAO;
import br.com.hrARA.dao.PerfilDAO;
import br.com.hrARA.dao.UsuarioDAO;
import br.com.hrARA.model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author higor
 */
@WebServlet(name = "CadastrarUsuario", urlPatterns = {"/CadastrarUsuario"})
public class CadastrarUsuario extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        Usuario oUsuario = new Usuario();
          
          
         try{
        oUsuario.setNome_usuario(request.getParameter("txtNome_usuario").toUpperCase());
        oUsuario.setContato_usuario(request.getParameter("txtContato_usuario"));
        oUsuario.setEmail_usuario(request.getParameter("txtEmail_usuario"));
        oUsuario.setSenha_usuario(request.getParameter("txtSenha_usuario"));
        oUsuario.setId_perfil(Integer.parseInt(request.getParameter("usuarios")));
                
      }catch (Exception ex){
          System.out.println("Problemas ao cadastrar UsuarioController. ERRO: " + ex.getMessage());
      }
         String mensagem = null;
         
        try {
            GenericDAO dao = new UsuarioDAO();
            if (request.getParameter("txtId_usuario").equals("")) {
                if (oUsuario.getNome_usuario().isEmpty()) {
                    
                    request.setAttribute("mensagem", "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\n" +
                                            "  <strong>NOME DO USUARIO FALTA SER PASSADO!!!</strong>\n" +
                                            "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n" +
                                            "    <span aria-hidden=\"true\">&times;</span>\n" +
                                            "  </button>\n" +
                                            "</div>");
                    request.getRequestDispatcher("cadastroRecurso.jsp").forward(request, response);
                    return;
                }
                
                if (dao.cadastrar(oUsuario)) {
                    mensagem = "<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">\n" +
                                "  <strong>Informações de Usuario salva!</strong>\n" +
                                "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n" +
                                "    <span aria-hidden=\"true\">&times;</span>\n" +
                                "  </button>\n" +
                                "</div>";
                } else {
                    mensagem = "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\n" +
                               "  <strong>Problemas ao cadastrar Usuario!</strong>\n" +
                               "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n" +
                               "    <span aria-hidden=\"true\">&times;</span>\n" +
                               "  </button>\n" +
                               "</div>";
                }
            } else {
                oUsuario.setId_usuario(Integer.parseInt(request.getParameter("txtId_usuario")));
                if (dao.alterar(oUsuario)) {
                    
                    mensagem = "<div class=\"alert alert-success alert-dismissible fade show\" role=\"alert\">\n"
                            + "  <strong>Informações do Usuário alterada com sucesso!</strong>\n"
                            + "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n"
                            + "    <span aria-hidden=\"true\">&times;</span>\n"
                            + "  </button>\n"
                            + "</div>";
                } else {
                    
                    mensagem = "<div class=\"alert alert-danger alert-dismissible fade show\" role=\"alert\">\n"
                            + "  <strong>Problemas ao alterar Usuario!</strong>\n"
                            + "  <button type=\"button\" class=\"close\" data-dismiss=\"alert\" aria-label=\"Close\">\n"
                            + "    <span aria-hidden=\"true\">&times;</span>\n"
                            + "  </button>\n"
                            + "</div>";
                }
            }
        } catch (Exception ex) {
            System.out.println("Problemas ao salvar Usuario! Erro: " + ex.getMessage());
            ex.printStackTrace();
        }
        
        request.setAttribute("mensagem", mensagem);
        request.getRequestDispatcher("DadosUsuario").forward(request, response);
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
