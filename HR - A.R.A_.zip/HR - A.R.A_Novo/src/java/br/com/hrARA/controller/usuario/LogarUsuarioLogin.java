/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.controller.usuario;

import br.com.hrARA.dao.ReservaDAO;
import br.com.hrARA.dao.UsuarioDAO;
import br.com.hrARA.model.Result;
import br.com.hrARA.model.Usuario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

/**
 *
 * @author rodol
 */
@WebServlet(name = "LogarUsuarioLogin", urlPatterns = {"/LogarUsuarioLogin"})
public class LogarUsuarioLogin extends HttpServlet {

    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        request.setCharacterEncoding("UTF-8");

        String mensagem;

        try {

            Usuario objUsuario = new Usuario();
            UsuarioDAO dao = new UsuarioDAO();
            ReservaDAO dao1 = new ReservaDAO();
            Result result = new Result();
            
            
            objUsuario.setSenha_usuario(request.getParameter("txtsenha_usuario"));
            objUsuario.setEmail_usuario(request.getParameter("txtnome_usuario"));

            objUsuario = dao.logar(objUsuario);
            
            if (objUsuario.getId_usuario() != 0) {

                HttpSession session = request.getSession(true);
                session.setAttribute("nome", objUsuario.getNome_usuario());
                session.setAttribute("cod_perfil", objUsuario.getCod_perfil());
                session.setAttribute("id_usuario", objUsuario.getId_usuario());
                if (objUsuario.getCod_perfil()!= 1) {
                    result = dao1.LogarListarPendentesUsuario(objUsuario);
                    session.setAttribute("pendentes", result.getResultado());
                    request.getRequestDispatcher("/DadosDashBoard").forward(request, response);
                } else {
                    result = dao1.LogarListarPendentesAdm();
                    session.setAttribute("pendentes", result.getResultado());
                    request.getRequestDispatcher("/DadosDashBoard").forward(request, response);
                }

            } else {

                mensagem = "<div class='alert alert-danger alert-dismissible fade show' role='alert'>\n"
                        + "  <strong>Erro:</strong> E-mail e/ou senha incorretos.\n"
                        + "  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n"
                        + "    <span aria-hidden='true' class='far fa-times-circle' ></span>\n"
                        + "  </button>\n"
                        + "</div>";

                request.setAttribute("mensagem", mensagem);
                request.getRequestDispatcher("/login.jsp").forward(request, response);

            }

        } catch (Exception ex) {

            mensagem = "<div class='alert alert-warning alert-dismissible fade show' role='alert'>\n"
                    + "  <strong>Erro:</strong> Problemas ao logar, tente mais tarde.\n"
                    + "  <button type='button' class='close' data-dismiss='alert' aria-label='Close'>\n"
                    + "    <span aria-hidden='true' class='far fa-times-circle' ></span>\n"
                    + "  </button>\n"
                    + "</div>";

            request.setAttribute("mensagem", mensagem);
            request.getRequestDispatcher("/login.jsp").forward(request, response);

            System.out.println("Erro ao LogarController:" + ex.getMessage());
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
