/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.dao;

import br.com.hrARA.model.ItemReserva;
import br.com.hrARA.model.Reserva;
import br.com.hrARA.model.Result;
import br.com.hrARA.model.Usuario;
import br.com.hrARA.utils.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author higor
 */
public class ReservaDAO implements GenericDAO {

    private Connection conn;
    private PreparedStatement stmt;

    public ReservaDAO() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
        } catch (Exception ex) {
            throw new Exception("Problemas ao conectar no BD! Erro: " + ex.getMessage());
        }
    }

    @Override
    public Boolean cadastrar(Object objeto) throws Exception {

        ItemReserva oItemreserva = (ItemReserva) objeto;
        PreparedStatement stmt = null;
        String sql = "insert into reserva (data_reserva,hora_reserva) values (?,?);";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setDate(1, new java.sql.Date(oItemreserva.getData_reserva().getTime()));
            stmt.setTime(2, new java.sql.Time(oItemreserva.getHora_reserva().getTime()));
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar a ReservaDAO(M1)! Erro: " + ex.getMessage());
            return false;
        }
    }

    @Override
    public Boolean alterar(Object objeto) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean excluir(int numero) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int numero) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Object> listar() {
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "select i.id_item_reserva,r.nome_recurso,u.nome_usuario,n.data_reserva,n.hora_reserva,r.quantidade_recurso, i.status_item_recurso\n" +
                    "from item_reserva i\n" +
                    "INNER JOIN recurso r on (i.fk_recurso = r.id_recurso)\n" +
                    "INNER JOIN usuario u on (i.fk_usuario = u.id_usuario)\n" +
                    "INNER JOIN reserva n on (i.fk_reserva = n.id_reserva)order by status_item_recurso desc;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Result oResult = new Result();
                oResult.setNome_recurso(rs.getString("nome_recurso"));
                oResult.setId_item_reserva(rs.getInt("id_item_reserva"));
                oResult.setNome_usuario(rs.getString("nome_usuario"));
                oResult.setData_reserva(rs.getDate("data_reserva"));
                oResult.setHora_reserva(rs.getTime("hora_reserva"));
                oResult.setQuantidade_recurso(rs.getInt("quantidade_recurso"));
                oResult.setStatus_reserva(rs.getInt("status_item_recurso"));
                resultado.add(oResult);
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar Reservas Pendetes! Erro: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        return resultado;
    }
    
    public List<Object> listarComum(int cod_perfil) {
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "select i.id_item_reserva,r.nome_recurso,u.nome_usuario,n.data_reserva,n.hora_reserva,r.quantidade_recurso from item_reserva i  \n"
                + "INNER JOIN recurso r on (i.fk_recurso = r.id_recurso)\n"
                + "INNER JOIN usuario u on (i.fk_usuario = u.id_usuario)\n"
                + "INNER JOIN reserva n on (i.fk_reserva = n.id_reserva)\n"
                + "where status_item_recurso = 3 and u.id_usuario = ? order by id_item_reserva;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, cod_perfil);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Result oResult = new Result();
                oResult.setNome_recurso(rs.getString("nome_recurso"));
                oResult.setId_item_reserva(rs.getInt("id_item_reserva"));
                oResult.setNome_usuario(rs.getString("nome_usuario"));
                oResult.setData_reserva(rs.getDate("data_reserva"));
                oResult.setHora_reserva(rs.getTime("hora_reserva"));
                oResult.setQuantidade_recurso(rs.getInt("quantidade_recurso"));
                resultado.add(oResult);
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar Reservas Pendetes! Erro: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        return resultado;
    }
    
    public List<Object> listarTudo() {
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "select i.id_item_reserva,r.nome_recurso,u.nome_usuario,n.data_reserva,n.hora_reserva,r.quantidade_recurso, i.status_item_recurso \n" +
                     "from item_reserva i\n" +
                     "INNER JOIN recurso r on (i.fk_recurso = r.id_recurso)\n" +
                     "INNER JOIN usuario u on (i.fk_usuario = u.id_usuario)\n" +
                     "INNER JOIN reserva n on (i.fk_reserva = n.id_reserva)order by id_item_reserva;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Result oResult = new Result();
                oResult.setNome_recurso(rs.getString("nome_recurso"));
                oResult.setId_item_reserva(rs.getInt("id_item_reserva"));
                oResult.setNome_usuario(rs.getString("nome_usuario"));
                oResult.setData_reserva(rs.getDate("data_reserva"));
                oResult.setHora_reserva(rs.getTime("hora_reserva"));
                oResult.setQuantidade_recurso(rs.getInt("quantidade_recurso"));
                oResult.setQuantidade_recurso(rs.getInt("status_item_recurso"));
                resultado.add(oResult);
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar Reservas Pendetes! Erro: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        return resultado;
    }

    public Boolean cadastrarItem(Object objeto) throws Exception {
        ItemReserva oItemReserva = (ItemReserva) objeto;
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "SELECT id_reserva FROM reserva ORDER BY Id_reserva DESC LIMIT 1;";
        String sql1 = "insert into item_reserva (fk_reserva,fk_recurso,fk_usuario,status_item_recurso,criado_item_recurso) values (?,?,?,?,now());";

        if (cadastrar(oItemReserva) == true) {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            if (rs.next()) {
                oItemReserva.setFk_reserva(Integer.parseInt(rs.getString("id_reserva")));
            }
        } else {
            System.out.println("Problemas ao cadastrar o cadastro reserva que voltou");
        }

        try {
            stmt = conn.prepareStatement(sql1);
            stmt.setInt(1, oItemReserva.getFk_reserva());
            stmt.setInt(2, oItemReserva.getFk_recurso());
            stmt.setInt(3, oItemReserva.getFk_usuario());
            stmt.setInt(4, oItemReserva.getStatus_item_recurso());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar a ReservaDAO(M2)! Erro: " + ex.getMessage());
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar parametros de conexão!" + "Erro: " + ex.getMessage());
            }
        }
    }

    public Boolean AprovarItem(Object objeto) throws Exception {
        Result oResult = (Result) objeto;
        Integer aprov = 1;
        PreparedStatement stmt = null;
        String sql = "UPDATE item_reserva SET status_item_recurso=? WHERE id_item_reserva=?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, aprov);
            stmt.setInt(2, oResult.getId_item_reserva());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problemas ao Aprovar Item da Reserva! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
    }

    public Boolean ReprovarItem(Object objeto) throws Exception {
        Result oResult = (Result) objeto;
        Integer aprov = 2;
        PreparedStatement stmt = null;
        String sql = "UPDATE item_reserva SET status_item_recurso=? WHERE id_item_reserva=?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, aprov);
            stmt.setInt(2, oResult.getId_item_reserva());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problemas ao Reprovar Item da Reserva! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar a conexão com o BD! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    public Result ListarPendetes(int id_usuario) {

        Result retorno = new Result();
        ResultSet rs = null;

        String sql = "select count(id_item_reserva) from item_reserva where status_item_recurso = 3 and fk_usuario = ?";

        try {

            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, id_usuario);
            rs = stmt.executeQuery();

            if (rs.next()) {
                retorno.setResultado(rs.getInt("count"));
            }
        } catch (SQLException ex) {

            System.out.println("Problemas ao Listar Itens aprovados DAO. ERRO: " + ex.getMessage());

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar a conexão com o BD! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        return retorno;
    }

    public Result LogarListarPendentesUsuario(Usuario objUsuario) {

        Result retorno = new Result();
        ResultSet rs = null;

        String sql = "select count(id_item_reserva) from item_reserva where status_item_recurso = 3 and fk_usuario = ?";

        try {

            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, objUsuario.getId_usuario());
            rs = stmt.executeQuery();

            if (rs.next()) {
                retorno.setResultado(rs.getInt("count"));
            }
        } catch (SQLException ex) {

            System.out.println("Problemas ao Listar Itens aprovados DAO. ERRO: " + ex.getMessage());

        }
        return retorno;
    }
    
    public Result LogarListarPendentesAdm() {

        Result retorno = new Result();
        ResultSet rs = null;

        String sql = "select count(id_item_reserva) from item_reserva where status_item_recurso = 3";

        try {

            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            if (rs.next()) {
                retorno.setResultado(rs.getInt("count"));
            }
        } catch (SQLException ex) {

            System.out.println("Problemas ao Listar Itens aprovados DAO. ERRO: " + ex.getMessage());

        }
        return retorno;
        
    }

}
