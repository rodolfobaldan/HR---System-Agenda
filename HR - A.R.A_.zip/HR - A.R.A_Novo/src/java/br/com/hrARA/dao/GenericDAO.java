/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.dao;

import java.util.List;

/**
 *
 * @author rodol
 */
public interface GenericDAO {
    public Boolean cadastrar(Object objeto) throws Exception;
    //public Boolean inserir(Object objeto) throws Exception;
    public Boolean alterar(Object objeto) throws Exception;
    public Boolean excluir(int numero) throws Exception;
    public Object carregar(int numero) throws Exception;
    public List<Object> listar();
}
