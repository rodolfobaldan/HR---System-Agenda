/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.dao;

import br.com.hrARA.model.Perfil;
import br.com.hrARA.utils.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author rodol
 */
public class PerfilDAO implements GenericDAO{
    
    private Connection conn;

    public PerfilDAO() throws Exception {
        try {            
            this.conn = ConnectionFactory.getConnection();
        } catch (Exception ex) {
            throw new Exception("Problemas ao conectar no BD! Erro: " + ex.getMessage());
        }
    }

    @Override
    public Boolean cadastrar(Object objeto) throws Exception {
        Perfil oPerfil = (Perfil) objeto;
        PreparedStatement stmt = null;
        String sql = "insert into perfil (descricao_perfil,criado_perfil,cod_perfil) values (?,now(),?)";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, oPerfil.getNomePerfil().toUpperCase());
            stmt.setInt(2, oPerfil.getCod_perfil());
            //stmt.setTimestamp(3, oPerfil.getModificadoPerfil());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar a PerfilDAO! Erro: " + ex.getMessage());
            return false;
        }
        finally{
            try{
                ConnectionFactory.closeConnection(conn, stmt);
            }
            catch(Exception ex){
                System.out.println("Problemas ao fechar parametros de conexão!" + "Erro: " + ex.getMessage());
            }
        }
    }

    @Override
    public Boolean alterar(Object objeto) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean excluir(int numero) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int numero) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Object> listar() {
         List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM perfil";
        
        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Perfil oPerfil = new Perfil();
                oPerfil.setIdPerfil(rs.getInt("id_perfil"));
                oPerfil.setCod_perfil(rs.getInt("cod_perfil"));
                oPerfil.setNomePerfil(rs.getString("descricao_perfil"));
                resultado.add(oPerfil);
            }
            
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar PERFILdao! Erro: " + ex.getMessage());
            ex.printStackTrace();            
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        System.out.println(resultado);
        return resultado;       
    }
    
}
