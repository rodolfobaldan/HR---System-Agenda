/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.dao;

import br.com.hrARA.model.Recurso;
import br.com.hrARA.utils.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author higor
 */
public class RecursoDAO implements GenericDAO{
     
    private Connection conexao;
    
    public RecursoDAO(){
        try {
            this.conexao = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso");
        } catch (Exception ex) {
            System.out.println("Problemas ao conectar no BD! Erro: "
                        +ex.getMessage());
        }
    }
    @Override
    public Boolean cadastrar(Object objeto) throws Exception {
        Recurso oRecurso = (Recurso) objeto;
        PreparedStatement stmt = null;
        String sql = "insert into recurso (nome_recurso,quantidade_recurso,status_recurso,criado_recurso) values (?,?,?,now())";
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, oRecurso.getNome_recurso().toUpperCase());
            stmt.setInt(2, oRecurso.getQuantidade_recurso());
            stmt.setInt(3, oRecurso.getStatus_recurso());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar a RecursoDAO! Erro: " + ex.getMessage());
            return false;
        }
        finally{
            try{
                ConnectionFactory.closeConnection(conexao, stmt);
            }
            catch(Exception ex){
                System.out.println("Problemas ao fechar parametros de conexão!" + "Erro: " + ex.getMessage());
            }
        }
    }

    @Override
    public Boolean alterar(Object objeto) throws Exception {
        Recurso oRecurso = (Recurso) objeto;
        PreparedStatement stmt = null;
        String sql = "update recurso set nome_recurso=?, quantidade_recurso=?, status_recurso=?, modificado_recurso= now() where id_recurso=?";
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, oRecurso.getNome_recurso().toUpperCase());
            stmt.setInt(2, oRecurso.getQuantidade_recurso());
            stmt.setInt(3, oRecurso.getStatus_recurso());
            stmt.setInt(4, oRecurso.getId_recurso());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao alterar Cliente! Erro: "
                    + ex.getMessage());
            ex.printStackTrace();
            return false;
        }
        finally{
            try {
                ConnectionFactory.closeConnection(conexao, stmt);
            } catch (Exception ex) {
                Logger.getLogger(RecursoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    @Override
    public Boolean excluir(int numero) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int numero) throws Exception {
        int idRecurso = numero;
        PreparedStatement stmt = null;
        ResultSet rs= null;
        Recurso oRecurso = null;
        String sql="select * from recurso where id_recurso=?";
        
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setInt(1, idRecurso);
            rs=stmt.executeQuery();
            while (rs.next()){
                oRecurso = new Recurso();
                oRecurso.setId_recurso(rs.getInt("id_recurso"));
                oRecurso.setNome_recurso(rs.getString("nome_recurso"));
                oRecurso.setQuantidade_recurso(rs.getInt("quantidade_recurso"));
                oRecurso.setStatus_recurso(rs.getInt("status_recurso"));
            }
            
        } catch (Exception ex) {
            System.out.println("Problemas ao carregar dados do RecursoDAO! Erro: " +ex.getMessage());
            ex.printStackTrace();
        }
        finally{
            try {
                ConnectionFactory.closeConnection(conexao,stmt,rs);
            } catch (Exception ex) {
                Logger.getLogger(RecursoDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return oRecurso; //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Object> listar() {
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM recurso";
        
        try {
            stmt = conexao.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Recurso oRecurso = new Recurso();
                oRecurso.setId_recurso(rs.getInt("id_recurso"));
                oRecurso.setNome_recurso(rs.getString("nome_recurso"));
                oRecurso.setQuantidade_recurso(rs.getInt("quantidade_recurso"));
                oRecurso.setStatus_recurso(rs.getInt("status_recurso"));
                resultado.add(oRecurso);
            }
            
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar ReservaDAO! Erro: " + ex.getMessage());
            ex.printStackTrace();            
        } finally {
            try {
                ConnectionFactory.closeConnection(conexao, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        return resultado;   
    }
    
    public List<Object> listarRecursoAgendamento() {
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "SELECT * FROM recurso where status_recurso = 1";
        
        try {
            stmt = conexao.prepareStatement(sql);
            rs = stmt.executeQuery();
            
            while (rs.next()) {
                Recurso oRecurso = new Recurso();
                oRecurso.setId_recurso(rs.getInt("id_recurso"));
                oRecurso.setNome_recurso(rs.getString("nome_recurso"));
                oRecurso.setQuantidade_recurso(rs.getInt("quantidade_recurso"));
                oRecurso.setStatus_recurso(rs.getInt("status_recurso"));
                resultado.add(oRecurso);
            }
            
        } catch (SQLException ex) {
            System.out.println("Problemas ao listar ReservaDAO! Erro: " + ex.getMessage());
            ex.printStackTrace();            
        } finally {
            try {
                ConnectionFactory.closeConnection(conexao, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        System.out.println(resultado);
        return resultado;   
    }
    
}
