/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.dao;

import br.com.hrARA.model.Result;
import br.com.hrARA.model.Usuario;
import br.com.hrARA.utils.ConnectionFactory;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author higor
 */
public class UsuarioDAO implements GenericDAO {

    private Connection conexao;
    private String sql = "";
    private String sql1 = "";
    private PreparedStatement stmt;

    public UsuarioDAO() {
        try {
            this.conexao = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso");
        } catch (Exception ex) {
            System.out.println("Problemas ao conectar no BD! Erro: "
                    + ex.getMessage());
        }
    }

    @Override
    public Boolean cadastrar(Object objeto) throws Exception {
        Usuario oUsuario = (Usuario) objeto;
        PreparedStatement stmt = null;
        String sql = "insert into usuario (nome_usuario,contato_usuario,email_usuario,senha_usuario,criado_usuario,id_perfil) values (?,?,?,?,now(),?);";
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, oUsuario.getNome_usuario().toUpperCase());
            stmt.setString(2, oUsuario.getContato_usuario());
            stmt.setString(3, oUsuario.getEmail_usuario());
            stmt.setString(4, oUsuario.getSenha_usuario());
            stmt.setInt(5, oUsuario.getId_perfil());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar a UsuarioDAO! Erro: " + ex.getMessage());
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conexao, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar parametros de conexão!" + "Erro: " + ex.getMessage());
            }
        }
    }

    @Override
    public Boolean alterar(Object objeto) throws Exception {
        Usuario oUsuario = (Usuario) objeto;
        PreparedStatement stmt = null;
        String sql = "update usuario set nome_usuario=?, contato_usuario=?, email_usuario=?, senha_usuario=?, modificado_usuario= now(), id_perfil=? where id_usuario=?;";
        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, oUsuario.getNome_usuario().toUpperCase());
            stmt.setString(2, oUsuario.getContato_usuario());
            stmt.setString(3, oUsuario.getEmail_usuario());
            stmt.setString(4, oUsuario.getSenha_usuario());
            stmt.setInt(5, oUsuario.getId_perfil());
            stmt.setInt(6, oUsuario.getId_usuario());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar a UsuarioDAO! Erro: " + ex.getMessage());
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conexao, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar parametros de conexão!" + "Erro: " + ex.getMessage());
            }
        }
    }

    @Override
    public Boolean excluir(int numero) throws Exception {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int numero) throws Exception {
        int idUsuario = numero;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Usuario oUsuario = null;
        String sql = "select * from usuario where id_usuario=?";

        try {
            stmt = conexao.prepareStatement(sql);
            stmt.setInt(1, idUsuario);
            rs = stmt.executeQuery();
            while (rs.next()) {
                oUsuario = new Usuario();
                oUsuario.setId_usuario(rs.getInt("id_usuario"));
                oUsuario.setNome_usuario(rs.getString("nome_usuario"));
                oUsuario.setEmail_usuario(rs.getString("email_usuario"));
                oUsuario.setContato_usuario(rs.getString("contato_usuario"));
            }

        } catch (Exception ex) {
            System.out.println("Problemas ao carregar dados do RecursoDAO! Erro: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conexao, stmt, rs);
            } catch (Exception ex) {
                Logger.getLogger(UsuarioDAO.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return oUsuario;
    }

    @Override
    public List<Object> listar() {
        List<Object> resultado = new ArrayList<>();
        PreparedStatement stmt = null;
        ResultSet rs = null;
        String sql = "select p.descricao_perfil,p.cod_perfil,u.* from perfil p, usuario u where u.id_perfil = p.id_perfil";

        try {
            stmt = conexao.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Usuario oUsuario = new Usuario();
                oUsuario.setId_usuario(rs.getInt("id_usuario"));
                oUsuario.setContato_usuario(rs.getString("contato_usuario"));
                oUsuario.setEmail_usuario(rs.getString("email_usuario"));
                oUsuario.setNome_usuario(rs.getString("nome_usuario"));
                oUsuario.setSenha_usuario(rs.getString("senha_usuario"));
                oUsuario.setNomePerfil(rs.getString("descricao_perfil"));
                oUsuario.setCod_perfil(rs.getInt("cod_perfil"));
                resultado.add(oUsuario);
                System.out.println(resultado);
            }

        } catch (SQLException ex) {
            System.out.println("Problemas ao listar UsuarioDAO! Erro: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conexao, stmt, rs);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar os parâmetros de conexão! Erro: " + ex.getMessage());
                ex.printStackTrace();
            }
        }
        System.out.println(resultado);
        return resultado;
    }

    public Usuario logar(Usuario objUsuario) {

        Usuario retorno = new Usuario();
        ResultSet rs = null;
        ResultSet rs1 = null;

        sql = "Select * from usuario where email_usuario = ? and senha_usuario = ?";
        sql1 = "Select p.cod_perfil,u.* from perfil p, usuario u where (u.email_usuario = ? and u.senha_usuario = ?) and (p.id_perfil = ?)";

        try {

            stmt = conexao.prepareStatement(sql);
            stmt.setString(1, objUsuario.getEmail_usuario());
            stmt.setString(2, objUsuario.getSenha_usuario());
            rs = stmt.executeQuery();

            if (rs.next()) {

                retorno.setEmail_usuario(rs.getString("email_usuario"));
                retorno.setId_usuario(rs.getInt("id_usuario"));
                retorno.setNome_usuario(rs.getString("nome_usuario"));
                retorno.setSenha_usuario(rs.getString("senha_usuario"));
                retorno.setContato_usuario(rs.getString("contato_usuario"));
                retorno.setId_perfil(rs.getInt("id_perfil"));
                stmt = conexao.prepareStatement(sql1);
                stmt.setString(1, retorno.getEmail_usuario());
                stmt.setString(2, retorno.getSenha_usuario());
                stmt.setInt(3, retorno.getId_perfil());
                rs1 = stmt.executeQuery();
                if (rs1.next()) {
                    retorno.setCod_perfil(rs1.getInt("cod_perfil"));
                }
            }
        } catch (SQLException ex) {

            System.out.println("Problemas ao Logar UsuarioDAO. ERRO: " + ex.getMessage());

        }
        return retorno;
    }

    public List<Object> ListarTotalUsuario() {
        List<Object> resultado = new ArrayList<>();
        ResultSet rs = null;

        String sql = "select count(id_usuario) from Usuario";

        try {

            stmt = conexao.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Result retorno = new Result();
                retorno.setResultado(rs.getInt("count"));
                resultado.add(retorno);
            }
        } catch (SQLException ex) {

            System.out.println("Problemas ao Listar Itens aprovados DAO. ERRO: " + ex.getMessage());

        }
        return resultado;
    }

}
