/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.model;

import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author higor
 */
public class ItemReserva extends Reserva{
    private int id_item_reserva;
    private int status_item_recurso ;
    private int fk_usuario;
    private int fk_recurso; 
    private int fk_reserva;
    private Timestamp criado_item_recurso ;  
    private Timestamp modificado_item_recurso;

    public ItemReserva() {
    }

    public ItemReserva(int id_item_reserva, int status_item_recurso, int fk_usuario, int fk_recurso, int fk_reserva, Timestamp criado_item_recurso, Timestamp modificado_item_recurso, int id_reserva, Date data_reserva, Date hora_reserva) {
        super(id_reserva, data_reserva, hora_reserva);
        this.id_item_reserva = id_item_reserva;
        this.status_item_recurso = status_item_recurso;
        this.fk_usuario = fk_usuario;
        this.fk_recurso = fk_recurso;
        this.fk_reserva = fk_reserva;
        this.criado_item_recurso = criado_item_recurso;
        this.modificado_item_recurso = modificado_item_recurso;
    }

    public int getId_item_reserva() {
        return id_item_reserva;
    }

    public void setId_item_reserva(int id_item_reserva) {
        this.id_item_reserva = id_item_reserva;
    }

    public int getStatus_item_recurso() {
        return status_item_recurso;
    }

    public void setStatus_item_recurso(int status_item_recurso) {
        this.status_item_recurso = status_item_recurso;
    }

    public int getFk_usuario() {
        return fk_usuario;
    }

    public void setFk_usuario(int fk_usuario) {
        this.fk_usuario = fk_usuario;
    }

    public int getFk_recurso() {
        return fk_recurso;
    }

    public void setFk_recurso(int fk_recurso) {
        this.fk_recurso = fk_recurso;
    }

    public int getFk_reserva() {
        return fk_reserva;
    }

    public void setFk_reserva(int fk_reserva) {
        this.fk_reserva = fk_reserva;
    }

    public Timestamp getCriado_item_recurso() {
        return criado_item_recurso;
    }

    public void setCriado_item_recurso(Timestamp criado_item_recurso) {
        this.criado_item_recurso = criado_item_recurso;
    }

    public Timestamp getModificado_item_recurso() {
        return modificado_item_recurso;
    }

    public void setModificado_item_recurso(Timestamp modificado_item_recurso) {
        this.modificado_item_recurso = modificado_item_recurso;
    }

   
}
