/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.model;

import java.util.Date;

/**
 *
 * @author higor
 */
public class Result {

    private String nome_recurso;
    private String nome_usuario;
    private Date data_reserva;
    private Date hora_reserva;
    private int quantidade_recurso;
    private int id_item_reserva;
    private Integer resultado;
    private int status_reserva;

    public Result() {
    }

    public Result(String nome_recurso, String nome_usuario, Date data_reserva, Date hora_reserva, int quantidade_recurso, int id_item_reserva, Integer resultado, int status_reserva) {
        this.nome_recurso = nome_recurso;
        this.nome_usuario = nome_usuario;
        this.data_reserva = data_reserva;
        this.hora_reserva = hora_reserva;
        this.quantidade_recurso = quantidade_recurso;
        this.id_item_reserva = id_item_reserva;
        this.resultado = resultado;
        this.status_reserva = status_reserva;
    }

    public String getNome_recurso() {
        return nome_recurso;
    }

    public void setNome_recurso(String nome_recurso) {
        this.nome_recurso = nome_recurso;
    }

    public String getNome_usuario() {
        return nome_usuario;
    }

    public void setNome_usuario(String nome_usuario) {
        this.nome_usuario = nome_usuario;
    }

    public Date getData_reserva() {
        return data_reserva;
    }

    public void setData_reserva(Date data_reserva) {
        this.data_reserva = data_reserva;
    }

    public Date getHora_reserva() {
        return hora_reserva;
    }

    public void setHora_reserva(Date hora_reserva) {
        this.hora_reserva = hora_reserva;
    }

    public int getQuantidade_recurso() {
        return quantidade_recurso;
    }

    public void setQuantidade_recurso(int quantidade_recurso) {
        this.quantidade_recurso = quantidade_recurso;
    }

    public int getId_item_reserva() {
        return id_item_reserva;
    }

    public void setId_item_reserva(int id_item_reserva) {
        this.id_item_reserva = id_item_reserva;
    }

    public Integer getResultado() {
        return resultado;
    }

    public void setResultado(Integer resultado) {
        this.resultado = resultado;
    }

    public int getStatus_reserva() {
        return status_reserva;
    }

    public void setStatus_reserva(int status_reserva) {
        this.status_reserva = status_reserva;
    }

    
    
    

}
