/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.model;

import java.util.Date;

/**
 *
 * @author higor
 */
public class Reserva {
    
     private int id_reserva;
    private Date data_reserva;
    private Date hora_reserva;

    public Reserva() {
    }

    public Reserva(int id_reserva, Date data_reserva, Date hora_reserva) {
        this.id_reserva = id_reserva;
        this.data_reserva = data_reserva;
        this.hora_reserva = hora_reserva;
    }

    public int getId_reserva() {
        return id_reserva;
    }

    public void setId_reserva(int id_reserva) {
        this.id_reserva = id_reserva;
    }

    public Date getData_reserva() {
        return data_reserva;
    }

    public void setData_reserva(Date data_reserva) {
        this.data_reserva = data_reserva;
    }

    public Date getHora_reserva() {
        return hora_reserva;
    }

    public void setHora_reserva(Date hora_reserva) {
        this.hora_reserva = hora_reserva;
    }

  
}
