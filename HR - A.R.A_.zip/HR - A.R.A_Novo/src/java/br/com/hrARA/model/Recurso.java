/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.model;

/**
 *
 * @author higor
 */
public class Recurso {
    private int id_recurso;
    private String nome_recurso;
    private int quantidade_recurso;
    private int status_recurso;

    public Recurso() {
    }

    public Recurso(int id_recurso, String nome_recurso, int quantidade_recurso, int status_recurso) {
        this.id_recurso = id_recurso;
        this.nome_recurso = nome_recurso;
        this.quantidade_recurso = quantidade_recurso;
        this.status_recurso = status_recurso;
    }

    public int getId_recurso() {
        return id_recurso;
    }

    public void setId_recurso(int id_recurso) {
        this.id_recurso = id_recurso;
    }

    public String getNome_recurso() {
        return nome_recurso;
    }

    public void setNome_recurso(String nome_recurso) {
        this.nome_recurso = nome_recurso;
    }

    public int getQuantidade_recurso() {
        return quantidade_recurso;
    }

    public void setQuantidade_recurso(int quantidade_recurso) {
        this.quantidade_recurso = quantidade_recurso;
    }

    public int getStatus_recurso() {
        return status_recurso;
    }

    public void setStatus_recurso(int status_recurso) {
        this.status_recurso = status_recurso;
    }
    
    
}
