/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.hrARA.model;

import java.sql.Timestamp;

/**
 *
 * @author rodol
 */
public class Perfil {
    
    private int idPerfil;
    private String nomePerfil;
    private int cod_perfil;
    private Timestamp criadoPerfil;
    private Timestamp modificadoPerfil;

    public Perfil() {
    }

    public Perfil(int idPerfil, String nomePerfil, int cod_perfil, Timestamp criadoPerfil, Timestamp modificadoPerfil) {
        this.idPerfil = idPerfil;
        this.nomePerfil = nomePerfil;
        this.cod_perfil = cod_perfil;
        this.criadoPerfil = criadoPerfil;
        this.modificadoPerfil = modificadoPerfil;
    }

    public int getIdPerfil() {
        return idPerfil;
    }

    public void setIdPerfil(int idPerfil) {
        this.idPerfil = idPerfil;
    }

    public String getNomePerfil() {
        return nomePerfil;
    }

    public void setNomePerfil(String nomePerfil) {
        this.nomePerfil = nomePerfil;
    }

    public int getCod_perfil() {
        return cod_perfil;
    }

    public void setCod_perfil(int cod_perfil) {
        this.cod_perfil = cod_perfil;
    }

    public Timestamp getCriadoPerfil() {
        return criadoPerfil;
    }

    public void setCriadoPerfil(Timestamp criadoPerfil) {
        this.criadoPerfil = criadoPerfil;
    }

    public Timestamp getModificadoPerfil() {
        return modificadoPerfil;
    }

    public void setModificadoPerfil(Timestamp modificadoPerfil) {
        this.modificadoPerfil = modificadoPerfil;
    }
    
    
}
